<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Restapi extends CI_Controller {

	public function __construct()
                {
                    parent::__construct();
                    $this->load->helper('form');
                    //$this->load->helper('url');
                    $this->load->helper('url_helper');
                    $this->load->library('form_validation');
                    $this->load->library('session');
                    $this->load->library(array('email', 'table'));
                    
                    $this->load->model('rest_model');
                }
	public function index()
	{
		$this->load->view('show_all');
	}
	
	 
	public	function createContact()
	 {
	 	// 	$params = json_decode ( file_get_contents ( "php://input" ) ); for raw data
	  $this->form_validation->set_rules("first_name", "First Name", "required");
	  $this->form_validation->set_rules("last_name", "Last Name", "required");
	  $this->form_validation->set_rules("email", "Email", "required");
	  $this->form_validation->set_rules("mobile_number", "Mobile Number", "required");
	  $array = array();
	  if($this->form_validation->run())
	  {
	   $data = array(
	    'first_name' => trim($this->input->post('first_name')),
	    'last_name'  => trim($this->input->post('last_name')),
	    'email' => trim($this->input->post('email')),
	    'mobile_number'  => trim($this->input->post('mobile_number')),
	    'created_on'  => date("Y-m-d H:i:s")
	   );
	   $this->rest_model->save($data);
	   $array = array(
	    'success'  => true
	   );
	  }
	  else
	  {
	   $array = array(
	    'error'    => true,
	    'first_name_error' => form_error('first_name'),
	    'last_name_error' => form_error('last_name'),
	    'email_error' => form_error('email'),
	    'mobile_number_error' => form_error('mobile_number'),
	    'message' => validation_errors()
	   );
	  }
	  echo json_encode($array, true);
	 }
	public function getAllContacts()
	 {
	  
	   $data = $this->rest_model->fetch_contacts();
	   foreach($data as $row)
	   {
	    $output['first_name'] = $row["first_name"];
	    $output['last_name'] = $row["last_name"];
	    $output['email'] = $row["email"];
	    $output['mobile_number'] = $row["mobile_number"];
	   }
	   echo json_encode($data);
	  
	 }
	public function getContact()
	 {
	  if($this->input->post('contact_id'))
	  {
	   $data = $this->rest_model->fetch_single_contact($this->input->post('contact_id'));
	   foreach($data as $row)
	   {
	    $output['first_name'] = $row["first_name"];
	    $output['last_name'] = $row["last_name"];
	   }
	   echo json_encode($output);
	  }
	 }

	public function updateContact()
	 {
	  $this->form_validation->set_rules("first_name", "First Name", "required");
	  $this->form_validation->set_rules("last_name", "Last Name", "required");
	  $this->form_validation->set_rules("email", "Email", "required");
	  $this->form_validation->set_rules("mobile_number", "Mobile Number", "required");
	  $this->form_validation->set_rules("mobile_number", "Mobile Number", "required");
	  $this->form_validation->set_rules("contact_id", "Contact id", "required");
	  $array = array();
	  if($this->form_validation->run())
	  {
	   $data = array(
	    'first_name' => trim($this->input->post('first_name')),
	    'last_name'  => trim($this->input->post('last_name')),
	    'email' => trim($this->input->post('email')),
	    'mobile_number'  => trim($this->input->post('mobile_number')),
	    'updated_on'  => date("Y-m-d H:i:s")
	   );
	   $this->rest_model->update_contact($this->input->post('contact_id'), $data);
	   $array = array(
	    'success'  => true
	   );
	  }
	  else
	  {
	   $array = array(
	    'error'    => true,
	    'first_name_error' => form_error('first_name'),
	    'last_name_error' => form_error('last_name'),
	    'email_error' => form_error('email'),
	    'mobile_number_error' => form_error('mobile_number'),
	    'contact_id_error' => form_error('contact_id')
	   );
	  }
	  echo json_encode($array, true);
	 }

	public function deleteContact()
	 {
	  if($this->input->post('contact_id'))
	  {
	   if($this->rest_model->delete_single_contact($this->input->post('contact_id')))
	   {
	    $array = array(
	     'success' => true
	    );
	   }
	   else
	   {
	    $array = array(
	     'error' => true
	    );
	   }
	   echo json_encode($array);
	  }
	 }
}
