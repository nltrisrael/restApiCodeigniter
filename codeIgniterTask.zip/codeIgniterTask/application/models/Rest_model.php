<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rest_model extends CI_Model
{
    
    const TABLE_NAME = "user_data";
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function save($userDetails)
	{
		$this->db->insert(self::TABLE_NAME, $userDetails);
		return $this->db->insert_id();
	} 

	public function fetch_single_contact($user_id)
	 {
	  $this->db->where("id", $user_id);
	  $query = $this->db->get('user_data');
	  return $query->result_array();
	 }
	public function fetch_contacts()
	 {
	  $query = $this->db->get('user_data');
	  return $query->result_array();
	 }

	public function update_contact($user_id, $data)
	 {
	  $this->db->where("id", $user_id);
	  $this->db->update("user_data", $data);
	 }
 
	public function delete_single_contact($user_id)
	 {
		  $this->db->where("id", $user_id);
		  $this->db->delete("user_data");
		  if($this->db->affected_rows() > 0)
		  {
		   	return true;
		  }
		  else
		  {
		   	return false;
		  }
	 }
	
}